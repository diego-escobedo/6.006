from Binary_Tree_Set import BST_Node, Binary_Tree_Set
# ----------------------------------- #
# DO NOT REMOVE THIS IMPORT STATEMENT # 
# DO NOT MODIFY IMPORTED CODE         #
# ----------------------------------- #


class Temperature_DB_Node(BST_Node):
    def subtree_update(A):
        super().subtree_update()
        # ------------------------------------ #
        # YOUR CODE IMPLEMENTING PART (A) HERE #
        # ------------------------------------ #

    def subtree_max_in_range(A, d1, d2):
        max_temp = None
        # ------------------------------------ #
        # YOUR CODE IMPLEMENTING PART (C) HERE #
        # ------------------------------------ #
        return max_temp


# ----------------------------------- #
# DO NOT MODIFY CODE BELOW HERE       # 
# ----------------------------------- #
class Measurement:
    def __init__(self, temp, date):
        self.key  = date
        self.temp = temp

    def __str__(self): 
        return "%s,%s" % (self.key, self.temp)

class Temperature_DB(Binary_Tree_Set):
    def __init__(self): 
        super().__init__(Temperature_DB_Node)

    def record_temp(self, t, d):
        try:
            m = self.delete(d)
            t = max(t, m.temp)
        except: pass
        self.insert(Measurement(t, d))

    def max_in_range(self, d1, d2):
        return self.root.subtree_max_in_range(d1, d2)
