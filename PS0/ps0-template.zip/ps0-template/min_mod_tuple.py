def min_mod_tuple(A, k):
    i, j = 0, 1
    ##################
    # Your Code Here #
    ##################
    return (i, j)
