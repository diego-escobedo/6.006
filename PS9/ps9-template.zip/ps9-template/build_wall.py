def build_wall(B):
    '''
    Input:  B | a border plan corresponding to 
              | a length-5 array of length-n strings 
    Output: P | a complete non-overlapping placement for B
              | that minimizes the number of cube stones used
    '''
    P = []
    ##################
    # YOUR CODE HERE #
    ##################
    return P
