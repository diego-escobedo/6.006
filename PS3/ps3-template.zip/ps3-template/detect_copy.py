def detect_copy(D, Q):
    '''
    Input:  D | an ASCII string 
    Output: Q | an ASCII string where |Q| < |D|
    '''
    p = 2**31 - 1
    ##################
    # YOUR CODE HERE #
    ##################
    return False
